<?php
include("header.php");
?>

<h3>Invalid User Details</h3>

<p>
The details you provided are invalid. Please <a href="user_register.php">try again</a>.
</p>


<?php
include("footer.php");
?>