<?php


$servername = "localhost";
$username = "root";
$password = "";
$dbname = "mygiftplanner";

$port = "3306";
$charset = 'utf8mb4';

?>